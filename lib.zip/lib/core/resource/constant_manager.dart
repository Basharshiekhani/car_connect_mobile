

abstract class AppConstantManager {
  static const String assetTranslationPath = 'assets/translations';
  static const String appIpConnectionTest = '8.8.8.8';
  // static const String baseUrl = 'http://192.168.100.31:8000';
  // static const String imageUrl = 'http://192.168.100.31:8000/storage';

}
