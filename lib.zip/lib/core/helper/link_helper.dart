abstract class LinkHelper{

  static String newInsuranceRequestLink= '';
  static String  registerLink='' ;
}